---
title: SAR Doc
hide:
  - navigation
  - toc
---

## Flat Data

Buscas integradas às bases de dados da ANAC usando Flat Data. 

- [_Flat Data_](/sardoc/Ferramentas/flat-data/flat-data/)
- [_Flat Data_ - instruções](/sardoc/Ferramentas/flat-data/instrucoes-flat-data/)
