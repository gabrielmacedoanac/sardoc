---
hide:
  - toc
disqus: ""
---

# Dados abertos da ANAC

## Repositório de dados abertos ANAC tratados
[Base](https://octo-repo-visualization.vercel.app/?repo=gabrielmacedoanac%2Fflat-data-anac)

<iframe src="https://octo-repo-visualization.vercel.app/?repo=gabrielmacedoanac%2Fflat-data-anac" width="100%" class="wide max-h-[35rem]" style="height: 90vh;"></iframe>
